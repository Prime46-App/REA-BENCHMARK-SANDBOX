# REA benchmark baseline — 2026-10-15

Original JavaScript fixture: normalize, search/filter, sort, immutable toggle, summarize.

Baseline: complete source code reviewed and seven independent Node tests. Initial test contained incorrect expectation for alphabetical tie breaker; original failure retained as initial-test-output.txt, corrected expectation, rerun passed.

Host Node 22.16.0, below upstream REA minimum 22.19. REA not installed or run. Comparison cannot yet be completed. No external dependencies, no secrets, no project access.

Next gate: disposable isolated runtime compatible Node, pin and audit REA package, disallow egress and privileged access, inspect static fixture only, collect JSON output and comparison. Do not run REA setup on production or connect to ECHO.
