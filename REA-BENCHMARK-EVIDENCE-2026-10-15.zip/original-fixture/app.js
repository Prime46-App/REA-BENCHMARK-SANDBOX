export const items = [
  {id:"a",title:"Weekly plan",done:false,priority:2},
  {id:"b",title:"Review audit",done:true,priority:1},
  {id:"c",title:"Prepare demo",done:false,priority:1}
];
export function normalizeQuery(input) {
  return String(input ?? "").trim().toLocaleLowerCase("en-US");
}
export function filterItems(data,{query="",showDone=false}={}) {
  const q=normalizeQuery(query);
  return data.filter(item=>(showDone || !item.done) && item.title.toLocaleLowerCase("en-US").includes(q))
    .toSorted((a,b)=>a.priority-b.priority || a.title.localeCompare(b.title));
}
export function toggleDone(data,id){
  if(!data.some(item=>item.id===id)) return data;
  return data.map(item=>item.id===id?{...item,done:!item.done}:item);
}
export function summarize(data){
  return {total:data.length,completed:data.filter(x=>x.done).length};
}
